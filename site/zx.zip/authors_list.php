<?php
require 'ini.php';





$nml = 50;
//$smarty->debugging = true;

$order=$_REQUEST['order'];
$letter=$_REQUEST['letter'];
$up=$_REQUEST['up'];
$fr=$_REQUEST['fr'];
$lm=$_REQUEST['lm'];
$sr=$_REQUEST['sr'];
$search=$_REQUEST['search'];
$srtype=$_REQUEST['srtype'];
$srtext=strtolower($_REQUEST['srtext']);


if (!$order) {$order="nickname";}
if ($order=="num_tracks" or $order=="years_from") {$letter="ALL";}
if (!$mask) {$mask=2;}
if (!$letter) {$letter="ALL";}
if (!$up) {$up="ASC";}
if (!$fr) {$fr=1;}
if (!$lm or $lm < $nml) {$lm = $nml;}
if ($sr) {$letter="ALL";}


function geturl($i){
  global $id,$fr,$lm,$up,$order,$letter,$sr;
  $a="/authors_list.php?";
  if ($fr and $fr!=1) {$a.="&fr=".$fr;}
  if ($lm and $lm!=$nml) {$a.="&lm=".$lm;}
  if ($up and $up!=ASC) {$a.="&up=".$up;}
  if ($sr) {$a.="&sr=".$sr;}
  if ($letter and $letter!="ALL") {$a.="&letter=".$letter;}
  if ($order and $order!="nickname") {$a.="&order=".$order;}
  return $a;
}


$fr2=($fr-1)*$nml;



$mode[$md]="class=selected";
$smarty->assign('mode',$mode);
$smarty->assign('sel_link',"http://zxtunes.com/authors_list.php?fr=".$fr."&lm=".$lm."&up=".$up."&ord=".$ord);



if ($_SESSION['language']=="rus") {


$smarty->assign('mmenu',
    array('news' => 'новости',
          'soft' => 'софт',
          'hard' => 'железо',
		  'articles' => 'статьи',
          'stats' => 'статистика',
          'forum' => 'форум',
          'music' => 'музыка',
          'authors' => 'авторская',
		  'games' => 'игровая',
          'demos' => 'демошная',
          'press' => 'из прессы',
          'party' => 'с патей',
          'remixes' => 'ремиксы'
		  )
         );

$tb[0]="ник";
$tb[1]="имя";
$tb[2]="фамилия";
$tb[3]="группа";
$tb[4]="треки";
$tb[5]="активность ";
$tb[6]="город";
$tb[7]="страна";

$au['nickname']="никам";
$au['first_name']="именам";
$au['last_name']="фамилиям";
$au['group_name']="группам";
$au['num_tracks']="количеству треков";
$au['years_from']="годам активности";
$au['city']="городам";
$au['country']="странам";
$au['interview']="интервью";
$au['photo']="фото";
$au['contact']="контактами";
$au['views']="количеству просмотров";

$smarty->assign('au', "Музыканты");
$smarty->assign('per', "по");
if ($order=="interview" or $order=="photo" or $order=="contact" ) {$smarty->assign('per', "с");}

$smarty->assign('kl1', "показано");
$smarty->assign('kl3', "из");
$all="ВСЕ";

$smarty->assign('title', "Музыканты по ".$au[$order]);
}
else {

$lang="_en";
$smarty->assign('mmenu',
    array('news' => 'news',
          'soft' => 'software',
          'hard' => 'hardware',
		  'articles' => 'articles',
          'stats' => 'statistics',
          'forum' => 'forum',
          'music' => 'music',
          'authors' => 'authors',
		  'games' => 'games',
          'demos' => 'demos',
          'press' => 'press',
          'party' => 'parties',
          'remixes' => 'remixes'
		  )
         );
		 
$tb[0]="nickname";
$tb[1]="fr. name";
$tb[2]="ls. name";
$tb[3]="group";
$tb[4]="tunes";
$tb[5]="activity";
$tb[6]="city";
$tb[7]="country";

$au['nickname']="nicknames";
$au['first_name']="first names";
$au['last_name']="last names";
$au['group_name']="groups";
$au['num_tracks']="tunes";
$au['years_from']="activities";
$au['city']="cities";
$au['country']="countries";
$au['interview']="inteviews";
$au['photo']="photos";
$au['contact']="contacts";
$au['views']="views";
		 
$smarty->assign('au', "Musicians");
$smarty->assign('per', "by");

$smarty->assign('kl1', "musicians");
$smarty->assign('kl3', "from");
$all="ALL";

$smarty->assign('title', "Musicians by ".$au[$order]);
}
		 
$smarty->assign('srt', $au[$order]);

		 
$smarty->assign('active', array('authors' => 'class=active'));
		 
$smarty->compile_check = true;






// if ($search=="search" and strlen($srtext)>=2 and strlen($srtext)<20) {

	 // $v = mysql_query("SELECT * FROM muzx_authors WHERE nickname LIKE '%$srtext%' OR also1 LIKE '%$srtext%' OR also2 LIKE '%$srtext%' OR also3 LIKE '%$srtext%' OR also4 LIKE '%$srtext%' OR also5 LIKE '%$srtext%'" );
	 
// if (!$v) {echo mysql_error();}
// else { $klp=0; $n=0;
// while ($src = mysql_fetch_array($v)) {
// $srsr[0]=$src['id'];
// if ($srtext==strtolower($src['nickname']) or $srtext==strtolower($src['also1']) or $srtext==strtolower($src['also2']) or $srtext==strtolower($src['also3']) or $srtext==strtolower($src['also4']) or $srtext==strtolower($src['also5'])) {$klp++; $idsr=$src['id'];}
// }
// }
// if ($klp==1) {   header("Location: http://".$_SERVER['SERVER_NAME']."/author_profile.php?id=".$idsr."?ln=".$ln);
// exit;	


// } 


// }








$ord=$order;
if ($order=="city" or $order=="country" or $order=="first_name" or $order=="last_name") {$ord.=$lang;}

$zapros0=mysql_query("SELECT DISTINCT LEFT($ord, 1) FROM muzx_authors ORDER BY $ord ");
if (!$zapros0) {echo mysql_error();}
else { $n=0; $l=0;


$alfavit="<div id='Navigator2' style='DISPLAY: inline;' align='left'>";

if ($letter=="ALL" and !$sr) {$alfavit.= "<span class='Page'>$all</span> ";}
else {$alfavit.= "<a class='Page' href='?order=".$order."&letter=ALL'>$all</a> ";}

while ($alf = mysql_fetch_array($zapros0)) {
if ($alf[0]<="9" and !$n) {if ($letter=="123" and !$sr) {$alfavit.= "<span class='Page'>0..9</span> "; $n++;}
	elseif ($alf[0]<="9") {$alfavit.= "<a class='Page' href='?letter=123&order=".$order."'>0..9</a> "; $n++;}}

elseif ($alf[0]>"9") {if ($alf[0]>"Z" and !$l) 
{$alfavit.= "</div></td></tr><tr><td><div id='Navigator2' align='left'>"; $l++;}

if ($letter=="$alf[0]" and !$sr) {$alfavit.= "<span class='Page'>".$alf[0]."</span>";}
else {$alfavit.= "<a class='Page' href='?letter=".$alf[0]."&order=".$order."'>".$alf[0]."</a>";}}
}
}

$smarty->assign('alfavit', $alfavit."</div>");





$zapros2 = mysql_query("SELECT * FROM muzx_authors ");
if (!$zapros2) {echo mysql_error();}
else {$kl2 = mysql_num_rows($zapros2);}
mysql_free_result($zapros2);



if (!$sr and $letter=="ALL" or $order=="years_from" or $order=="num_tracks") {$like="";}
elseif ($letter=="123") {$like="WHERE ".$order." REGEXP ('^[0-9]')";}
elseif (!$sr) {$like="WHERE ".$ord." LIKE '".$letter."%'";}
else {$like="WHERE ".$ord." LIKE '".$sr."'"; $ord.=", nickname";}




$zapros = mysql_query("SELECT * FROM muzx_authors $like ORDER BY $ord $up ");
if (!$zapros) {echo mysql_error();}
else { $kl = mysql_num_rows($zapros);  mysql_free_result($zapros);}

$zapros = mysql_query("SELECT * FROM muzx_authors $like ORDER BY $ord $up LIMIT $fr2, $lm ");
if (!$zapros) {echo mysql_error();}
else { $kl5 = mysql_num_rows($zapros);  mysql_free_result($zapros);}

$zapros = mysql_query("SELECT * FROM muzx_authors");
if (!$zapros) {echo mysql_error();}
else { $kl6 = mysql_num_rows($zapros);  mysql_free_result($zapros);}

$kl2=Ceil($kl/40);



for ($i = 1; $i <= $kl2; $i++) {
	if ($fr==$i and $lm == $nml) {$pages.= "<span class='Page'>".$i."</span>";
	} else {$pages.= "<a class='Page' href='?id=".$id."&lm=40&fr=".$i."&order=".$order."&up=".$up."&letter=".$letter."&sr=".$sr."'>".$i."</a>";}
}
if ($lm > $nml) {$pages.= " <span class='Page'>$all</span>";} else {$pages.= "<a class='Page'href='?id=".$id."&lm=".$kl."&fr=1&order=".$order."&up=".$up."&letter=".$letter."&sr=".$sr."'>$all</a>";}

//echo "&nbsp&nbsp&nbsp&nbsp(".$kl5."/".$kl."/".$kl6.")<br><br>";

$smarty->assign('kl2', $kl5);
$smarty->assign('kl4', $kl);
$smarty->assign('pages', $pages);





$zapros = mysql_query("SELECT * FROM muzx_authors $like ORDER BY $ord $up LIMIT $fr2, $lm");



$tb_title[0]['link']="<a class='mb' href='?letter=".$letter."&order=nickname&lm=".$lm."&fr=1&up=";
if ($order=="nickname" and $up=="ASC") {$tb_title[0]['link'].= "DESC'>$tb[0]</a> <b>&#62</b>";} elseif ($order=="nickname" and $up=="DESC") {$tb_title[0]['link'].= "ASC'>$tb[0]</a> <b>&#60</b>";} else {$tb_title[0]['link'].= "ASC'>$tb[0]</a>";}


$tb_title[1]['link']= "<a class='mb' href='?letter=".$letter."&order=first_name&lm=".$lm."&fr=1&up=";
if ($order=="first_name" and $up=="ASC") {$tb_title[1]['link'].= "DESC'>$tb[1]</a> <b>&#62</b>";} elseif ($order=="first_name" and $up=="DESC") {$tb_title[1]['link'].= "ASC'>$tb[1]</a> <b>&#60</b>";} else {$tb_title[1]['link'].= "ASC'>$tb[1]</a>";}


$tb_title[2]['link']="<a class='mb' href='?letter=".$letter."&order=last_name&lm=".$lm."&fr=1&up=";
if ($order=="last_name" and $up=="ASC") {$tb_title[2]['link'].= "DESC'>$tb[2]</a> <b>&#62</b>";} elseif ($order=="last_name" and $up=="DESC") {$tb_title[2]['link'].= "ASC'>$tb[2]</a> <b>&#60</b>";} else {$tb_title[2]['link'].= "ASC'>$tb[2]</a>";}


if ($order=="group_name" and $up=="ASC" and !$sr) {$tb_title[3]['link'].= "<a class='mb' href='?letter=".$letter."&order=group_name&lm=".$lm."&fr=1&up=DESC'>$tb[3]</a> <b>&#62</b>";} 
elseif ($order=="group_name" and $up=="DESC" and !$sr) {$tb_title[3]['link'].= "<a class='mb' href='?letter=".$letter."&order=group_name&lm=".$lm."&fr=1&up=ASC'>$tb[3]</a> <b>&#60</b>";} 
elseif ($order=="group_name" and $sr) {$tb_title[3]['link'].= "<b>$tb[3]</b>: ".$sr." ";} 
else {$tb_title[3]['link'].= "<a class='mb' href='?letter=".$letter."&order=group_name&lm=".$lm."&fr=1&up=ASC'>$tb[3]</a>";}


$tb_title[4]['link']= "<a class='mb' href='?letter=".$letter."&order=num_tracks&lm=".$lm."&fr=1&up=";
if ($order=="num_tracks" and $up=="ASC") {$tb_title[4]['link'].= "DESC'>$tb[4]</a> <b>&#62</b>";} elseif ($order=="num_tracks" and $up=="DESC") {$tb_title[4]['link'].= "ASC'>$tb[4]</a> <b>&#60</b>";} else {$tb_title[4]['link'].= "ASC'>$tb[4]</a>";}


$tb_title[5]['link']= "<a class='mb' href='?letter=".$letter."&order=years_from&lm=".$lm."&fr=1&up=";
if ($order=="years_from" and $up=="ASC") {$tb_title[5]['link'].= "DESC'>$tb[5]</a> <b>&#62</b>";} elseif ($order=="years_from" and $up=="DESC") {$tb_title[5]['link'].= "ASC'>$tb[5]</a> <b>&#60</b>";} else {$tb_title[5]['link'].= "ASC'>$tb[5]</a>";}


if ($order=="city" and $up=="ASC" and !$sr) {$tb_title[6]['link']= "<a class='mb' href='?letter=".$letter."&order=city&lm=".$lm."&fr=1&up=DESC'>$tb[6]</a> <b>&#62</b>";} 
elseif ($order=="city" and $up=="DESC" and !$sr) {$tb_title[6]['link'].= "<a class='mb' href='?letter=".$letter."&order=city&lm=".$lm."&fr=1&up=ASC'>$tb[6]</a> <b>&#60</b>";} 
elseif ($order=="city" and $sr) {$tb_title[6]['link'].= "<b>$tb[6]</b>: ".$sr." ";} 
else {$tb_title[6]['link'].= "<a class='mb' href='?letter=".$letter."&order=city&lm=".$lm."&fr=1&up=ASC'>$tb[6]</a>";}


if ($order=="country" and $up=="ASC" and !$sr) {$tb_title[7]['link']= "<a class='mb' href='?letter=".$letter."&order=country&lm=".$lm."&fr=1&up=DESC'>$tb[7]</a> <b>&#62</b>";} 
elseif ($order=="country" and $up=="DESC" and !$sr) {$tb_title[7]['link'].= "<a class='mb' href='?letter=".$letter."&order=country&lm=".$lm."&fr=1&up=ASC'>$tb[7]</a> <b>&#60</b>";} 
elseif ($order=="country" and $sr) {$tb_title[7]['link'].= "<b>$tb[7]</b>: ".$sr." ";} 
else {$tb_title[7]['link'].= "<a class='mb' href='?letter=".$letter."&order=country&lm=".$lm."&fr=1&up=ASC'>$tb[7]</a>";}


if ($order=="interview" and $up=="ASC" and !$sr) {$tb_title[8]['link']= "<a class='mb' href='?order=interview&lm=".$lm."&fr=1&up=DESC'><img src='images/interview.png' border=0 title='interview with author'></a> <b>&#60</b>";} 
elseif ($order=="interview" and $up=="DESC" and !$sr) {$tb_title[8]['link'].= "<a class='mb' href='?order=interview&lm=".$lm."&fr=1&up=ASC'><img src='images/interview.png' border=0 title='interview with author'></a> <b>&#62</b>";} 
elseif ($order=="interview" and $sr) {$tb_title[8]['link'].= "interview: ".$sr." ";} 
else {$tb_title[8]['link'].="<a class='mb' href='?order=interview&lm=".$lm."&fr=1&up=DESC'><img src='images/interview.png' border=0 title='interview with author'></a>";}


if ($order=="photo" and $up=="ASC" and !$sr) {$tb_title[9]['link']= "<a class='mb' href='?order=photo&lm=".$lm."&fr=1&up=DESC'><img src='images/photo.png' border=0 title='author photo'></a> <b>&#60</b>";} 
elseif ($order=="photo" and $up=="DESC" and !$sr) {$tb_title[9]['link'].= "<a class='mb' href='?order=photo&lm=".$lm."&fr=1&up=ASC'><img src='images/photo.png' border=0 title='author photo'></a> <b>&#62</b>";} 
elseif ($order=="photo" and $sr) {$tb_title[9]['link'].= "photo: ".$sr." ";} 
else {$tb_title[9]['link'].= "<a class='mb' href='?order=photo&lm=".$lm."&fr=1&up=DESC'><img src='images/photo.png' border=0 title='author photo'></a>";}


if ($order=="contact" and $up=="ASC" and !$sr) {$tb_title[10]['link']= "<a class='mb' href='?order=contact&lm=".$lm."&fr=1&up=DESC'><img src='images/contact.png' border=0 title='contacts'></a> <b>&#60</b>";} 
elseif ($order=="contact" and $up=="DESC" and !$sr) {$tb_title[10]['link'].= "<a class='mb' href='?order=contact&lm=".$lm."&fr=1&up=ASC'><img src='images/contact.png' border=0 title='contacts'></a> <b>&#62</b>";} 
elseif ($order=="contact" and $sr) {$tb_title[10]['link'].= "contact: ".$sr." ";} 
else {$tb_title[10]['link'].= "<a class='mb' href='?order=contact&lm=".$lm."&fr=1&up=DESC'><img src='images/contact.png' border=0 title='contacts'></a>";}


if ($order=="views" and $up=="ASC" and !$sr) {$tb_title[11]['link']= "<a class='mb' href='?order=views&lm=".$lm."&fr=1&up=DESC'><img src='images/views.png' border=0 title='profile views'></a> <b>&#62</b>";} 
elseif ($order=="views" and $up=="DESC" and !$sr) {$tb_title[11]['link'].= "<a class='mb' href='?order=views&lm=".$lm."&fr=1&up=ASC'><img src='images/views.png' border=0 title='profile views'></a> <b>&#60</b>";} 
elseif ($order=="views" and $sr) {$tb_title[11]['link'].= "views: ".$sr." ";} 
else {$tb_title[11]['link'].= "<a class='mb' href='?order=views&lm=".$lm."&fr=1&up=DESC'><img src='images/views.png' border=0 title='profile views'></a>";}

$smarty->assign('tb_title', $tb_title);





if (!$zapros)
	echo mysql_error();
else
{   $n=0;
	while ($row1 = mysql_fetch_array($zapros))
	{
	    
		$y=$row1['years_from']."-".$row1['years_to'];
		if (!$row1['years_to'] and $row1['years_from']) {$y=$row1['years_from'];}
		elseif ($row1['years_from']==$row1['years_to'] and $row1['years_from']) {$y=$row1['years_from'];}
		elseif (!$row1['years_from']) {$y="—";}
		
		for ($i = 0; $i < 9; $i++) {
		if (!$row1[$i]) {$row1[$i]="—";}
		}
		if (!$row1['first_name'.$lang]) {$row1['first_name'.$lang]="—";}
		if (!$row1['last_name'.$lang]) {$row1['last_name'.$lang]="—";}
		if (!$row1['num_tracks']) {$row1['num_tracks']="0";}

		
		$gr=$row1['group_name'];
		$ct=$row1['city'.$lang];
	
	   
	
	
		$tbtx[$n][0]="<a class='m' href='author.php?id=".$row1['id']."'>".$row1['nickname']."</a>";
		$tbtx[$n][1]= $row1['first_name'.$lang];
		$tbtx[$n][2]= $row1['last_name'.$lang];
		
		if ($sr and $order=="group_name") {$tbtx[$n][3]= $gr;} 
		else {if ($row1['group_name']) {$tbtx[$n][3]= "<a class='mm' href='?letter=".$letter."&order=group_name&up=ASC&sr=".$row1['group_name']."'>".$gr."</a>";}
		    else {$tbtx[$n][3]="—";}
		}
	
		
		$tbtx[$n][4]= $row1['num_tracks'];
		$tbtx[$n][5]= $y;
		if ($sr and $order=="city") {$tbtx[$n][6]= $ct;} 
		else {if ($row1['city'.$lang]) {$tbtx[$n][6]= "<a class='mm' href='?letter=".$letter."&order=city&up=ASC&sr=".$row1['city'.$lang]."'>".$ct;}
		     else {$tbtx[$n][6]="—";}
		}
		
		if ($sr and $order=="country") {$tbtx[$n][7]= $row1['country'.$lang];} 
		else {if ($row1['country'.$lang]) {$tbtx[$n][7]= "<a class='mm' href='?letter=".$letter."&order=country&up=ASC&sr=".$row1['country'.$lang]."'>".$row1['country'.$lang];}
		     else {$tbtx[$n][7]="—";}
		}
		
		if ($row1['interview']) {$tbtx[$n][8]="+";} else {$tbtx[$n][8]="-";};
		if ($row1['photo']) {$tbtx[$n][9]="+";} else {$tbtx[$n][9]="-";};
		if ($row1['contact']) {$tbtx[$n][10]="+";} else {$tbtx[$n][10]="-";};
		$tbtx[$n][11]= $row1['views'];

	$n++;	
	}

mysql_free_result($zapros);
$smarty->assign('tbtx', $tbtx);
}


include "right_strip.php";  


$smarty->display('authors_list.tpl');
