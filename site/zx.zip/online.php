<?php

session_start();

include 'common.inc.php';

mysql_connect(DB_HOST, DB_USER, DB_PASS)
	or die(mysql_error());
mysql_select_db(DB_NAME)
	or die(mysql_error());
mysql_query("SET NAMES 'utf8'");

// $ses = mysql_query("SELECT * FROM online WHERE id_session = '$id_session'"); 

// if (!$ses) {echo mysql_error();}

// if(mysql_num_rows($ses)>0) 

  // {$query = mysql_query("UPDATE online SET putdate = NOW(), user = '$_SESSION[user]' WHERE id_session = '$id_session'");} 


// else {$ip=$_SERVER["REMOTE_ADDR"]; if (!$ip) {$ip=$_SERVER["http_referer"];}
// $client = $_SERVER[HTTP_USER_AGENT]; 
// if(!strstr($client,"Yandex") and !strstr($client,"Googlebot")) 


// $query = mysql_query("INSERT INTO online VALUES('$id_session', NOW(), '$_SESSION[user]', '$ip' )"); echo mysql_error(); 

// if (!$query) {echo mysql_error();}

// } 

//$query = mysql_query("DELETE FROM online WHERE putdate < NOW() -  INTERVAL '10' MINUTE"); 






$language=$_REQUEST['ln'];
if ($language=="rus" or $language=="eng") {$_SESSION['language']=$language;}
if ($_SESSION['language']) {} else {$_SESSION['language']="rus";}

$client = " ".$_SERVER[HTTP_USER_AGENT]; 
if(strstr($client,"Yandex") or strstr($client,"Googlebot")) {$bot=1;} else {$bot=0;}



$dir = "/var/www/newart/data/www/zxtunes.com/";
define('SMARTY_DIR', $dir.'smarty/libs/');
require_once(SMARTY_DIR . 'Smarty.class.php');
$smarty = new Smarty;

$smarty->template_dir = $dir.'smarty/zxtunes/templates/';
$smarty->compile_dir = $dir.'smarty/zxtunes/templates_c/';
$smarty->config_dir = $dir.'smarty/zxtunes/configs/';
$smarty->cache_dir = $dir.'smarty/zxtunes/cache/';




if (!defined('_SAPE_USER')){
	define('_SAPE_USER', 'df148749a7a956a4334286aea4e556e8'); 
}

require_once($_SERVER['DOCUMENT_ROOT'].'/'._SAPE_USER.'/sape.php'); 
$sape = new SAPE_client();


?>