<?php
error_reporting(false);

session_start();

define('DB_HOST', 'localhost');
define('DB_USER', 'tuneszx_8912');
define('DB_PASS', 'RJsBhivS8b');
define('DB_NAME', 'tuneszx_ay');

mysql_connect(DB_HOST, DB_USER, DB_PASS)
	or die(mysql_error());
mysql_select_db(DB_NAME)
	or die(mysql_error());
mysql_query("SET NAMES 'utf8'");


$language = $_REQUEST['ln'];

if (!$language) {$language = "rus";}
$_SESSION['language'] = $language;

//if ($_SESSION['language']) {$_SESSION['language']="eng";} else {$_SESSION['language']="rus";}


if ($language == "eng") {
	
		$amdate = array(
		"01"=>"January",
		"02"=>"February",
		"03"=>"March",
		"04"=>"April",
		"05"=>"May",
		"06"=>"June",
		"07"=>"July",
		"08"=>"August",
		"09"=>"September",
		"10"=>"October",
		"11"=>"November",
		"12"=>"December");

}
else {

		$amdate = array(
		"01"=>"января",
		"02"=>"февраля",
		"03"=>"марта",
		"04"=>"апреля",
		"05"=>"мая",
		"06"=>"июня",
		"07"=>"июля",
		"08"=>"августа",
		"09"=>"сентября",
		"10"=>"октября",
		"11"=>"ноября",
		"12"=>"декабря");

}

function my($var) {

	return trim(mysql_real_escape_string($_REQUEST[$var]));

}

function dt($var) {
	
	global $amdate;
	return date("d", $var) ." ".$amdate[date("m", $var)]." ".date("Y", $var);

}

function qr($from, $where) {

	$z = mysql_query("SELECT * FROM $from WHERE $where LIMIT 1" );
	return mysql_fetch_array($z);

}

function frame2time($var) {

	$s = ceil($var/50);
	$sec = sprintf("%02d", $s - ((intval($s/60)) * 60));
	$min = intval($s/60);
	return $min.":".$sec;
	
}


$dir = "/home/tuneszx/web/zxtunes.com/public_html/";
define('SMARTY_DIR', $dir.'smarty/libs/');
require_once(SMARTY_DIR . 'Smarty.class.php');
$smarty = new Smarty;

$smarty->template_dir = $dir.'smarty/zxtunes/templates/';
$smarty->compile_dir = $dir.'smarty/zxtunes/templates_c/';
$smarty->config_dir = $dir.'smarty/zxtunes/configs/';
$smarty->cache_dir = $dir.'smarty/zxtunes/cache/';

//unset($_SESSION['user_id']); unset($_SESSION['user_login']); unset($_SESSION['user_password']);

if (!login() and isset($_COOKIE['user_login']) and isset($_COOKIE['user_id']) and isset($_COOKIE['user_password']))
{
		
	$_SESSION['user_password'] = $_COOKIE['user_password'];//strrev(md5($_COOKIE['password']))."b3p6f"; 
	$_SESSION['user_login']=$_COOKIE['user_login'];
	$_SESSION['user_id']=$_COOKIE['user_id'];
	
	$u = qr( "users", "login='".$_SESSION['user_login']."' AND password='".$_SESSION['user_password']."'" );
	
	echo mysql_error();
	
	if (!$u['activation']) {
	
		unset($_SESSION['user_id']); unset($_SESSION['user_login']); unset($_SESSION['user_password']);
	
	}
	else {
	
		$_SESSION['user_author_id'] = $u['author_id'];
		$_SESSION['user_acess'] = $u['acess'];
		
	}
		
}


function login() {

	if ($_SESSION['user_password'] and $_SESSION['user_login'] and $_SESSION['user_id']) {return 1;}else {return 0;}

}

$user['password'] = $_SESSION['user_password'];
$user['login'] = $_SESSION['user_login'];
$user['id'] = $_SESSION['user_id'];
$user['author_id'] = $_SESSION['user_author_id'];
$user['acess'] = $_SESSION['user_acess'];

$smarty->assign('user',  $user);

unset($user); unset($u);



if (!defined('_SAPE_USER')){
	define('_SAPE_USER', 'df148749a7a956a4334286aea4e556e8'); 
}

require_once($_SERVER['DOCUMENT_ROOT'].'/'._SAPE_USER.'/sape.php'); 
$sape = new SAPE_client();


?>