<?php

require 'ini.php';



$id=$_REQUEST['id'];
$fr=$_REQUEST['fr'];
$lm=$_REQUEST['lm'];
$up=$_REQUEST['up'];
$ln=$_REQUEST['ln'];
$md=$_REQUEST['md'];
$order=$_REQUEST['order'];
$rate=$_REQUEST['rate'];
$tnid = explode("=", $md);
$ip=$_SERVER["REMOTE_ADDR"];
$client = " ".$_SERVER[HTTP_USER_AGENT]; 
if(strstr($client,"Yandex") or strstr($client,"Googlebot")) {$bot=1;} else {$bot=0;}


function geturl($i){
  $a="/stats.php?";
  return $a;
}


$smarty->compile_check = true;
$smarty->assign('active', array('stats' => 'class=active'));

//$smarty->debugging = true;

$mode[$md]="class=selected";
$smarty->assign('mode',$mode);
$smarty->assign('sel_link',"http://zxtunes.com/stats.php");



if ($_SESSION['language']=="rus") {
$smarty->assign('title',"Статистика");
}
else {
$smarty->assign('title',"Statistics");
}


$snd[1]="Sound Tracker";
$snd[2]="Sound Tracker Pro";
$snd[3]="Global Tracker";
$snd[4]="Fast Tracker";
$snd[5]="Pro Sound Maker";
$snd[6]="Pro Sound Creator";
$snd[7]="Pro Tracker 2.x";
$snd[8]="Pro Tracker 3.x";
$snd[9]='Unknown ("ay")';
$snd[10]='Unknown ("vtx")';
$snd[11]="SQ-Tracker";
$snd[12]="Asc Sound Master";
$snd[13]="Pro Tracker 1.x";
$snd[14]="Flash Tracker";
$snd[15]="Fuxoft AY";

$lns[1]=24;
$lns[2]=1;
$lns[4]=8;
$lns[5]=6;
$lns[6]=5;
$lns[7]=37;
$lns[8]=4;
$lns[11]=2;
$lns[12]=13;
$lns[13]=3;



$i=0;
$zapros7 = mysql_query("SELECT DISTINCT muzx_songs.type, COUNT(*) AS kl FROM muzx_songs WHERE type!=9 AND type!=10 AND type!=0 GROUP BY type ORDER BY kl DESC");
if (!$zapros7) {echo mysql_error();}
else {$kl_country = mysql_num_rows($zapros7);
while ($types=mysql_fetch_array($zapros7)) { 
$types['lnk']=$lns[$types['type']];
$types['type']=$snd[$types['type']];

$t[$i] = $types; $i++;

}
}
$smarty->assign('types', $t);




$i=0;
if ($_SESSION['language']!='rus') {$l="_en";}
$zapros7 = mysql_query("SELECT DISTINCT muzx_authors.country$l, COUNT(*) AS kl FROM muzx_authors WHERE country$l!='' GROUP BY country$l  ORDER BY kl DESC LIMIT 10");
if (!$zapros7) {echo mysql_error();}
else {$kl_country = mysql_num_rows($zapros7);
while ($authors=mysql_fetch_array($zapros7)) {$c[$i] = $authors; $i++;}
}
$smarty->assign('bycountry', $c);


$i=0;
$zapros6 = mysql_query("SELECT DISTINCT muzx_authors.city$l, COUNT(*) AS kl FROM muzx_authors WHERE city$l!='' GROUP BY city$l  ORDER BY kl DESC LIMIT 10");
if (!$zapros6) {echo mysql_error();}
else {$kl_city = mysql_num_rows($zapros6);
while ($authors=mysql_fetch_array($zapros6)) {$c[$i] = $authors; $i++;}
}
$smarty->assign('bycity', $c);

// $i=0;
// $zapros = mysql_query("SELECT DISTINCT  muzx_songs_authors.author_id, COUNT(*) AS kl FROM muzx_songs_authors GROUP BY author_id  ORDER BY kl DESC" );
// if (!$zapros) {echo mysql_error();}
// else
// { while ($songs=mysql_fetch_array($zapros)) {
// $id=$songs['author_id'];
// $zapros5 = mysql_query("SELECT * FROM muzx_authors WHERE id='$id' ");
// if (!$zapros5) {echo mysql_error();} else {$auth=mysql_fetch_array($zapros5);
// $author[$i]= "<a href='http://zxtunes.com/author_profile.php?id=".$id."&ln=".$ln."'>".$auth['nickname']."</a>: ".$songs[1]."<br>";
// $i++;
// }
// }
// }


$i=0;
$zapros = mysql_query("SELECT * FROM muzx_authors ORDER BY num_tracks DESC LIMIT 10");
if (!$zapros) {echo mysql_error();}
else
{ while ($auth=mysql_fetch_array($zapros)) {$auth['nm']=$i+1; $c[$i] = $auth; $i++;}
}
$smarty->assign('bytunes', $c);


$i=0;
$zapros4 = mysql_query("SELECT id, nickname, years_from, years_to, ((years_to) - (years_from)) AS act FROM muzx_authors WHERE years_from!='' AND years_to!='' ORDER BY act DESC LIMIT 10");
if (!$zapros4) {echo mysql_error();}
else {
while ($activ=mysql_fetch_array($zapros4)) {$activ[4]++; $c[$i]=$activ; $i++;}
}
$smarty->assign('byyears', $c);



$zapros8 = mysql_query("SELECT COUNT(*) FROM muzx_authors" );
if (!$zapros8) {echo mysql_error();}
else {$smarty->assign('authors', mysql_fetch_array($zapros8));
}

$zapros8 = mysql_query("SELECT COUNT(*) FROM muzx_authors WHERE photo='1' " );
if (!$zapros8) {echo mysql_error();}
else {$smarty->assign('photos', mysql_fetch_array($zapros8));
}

$zapros8 = mysql_query("SELECT COUNT(*) FROM interview " );
if (!$zapros8) {echo mysql_error();}
else {$smarty->assign('interviews',mysql_fetch_array($zapros8));
}

$zapros8 = mysql_query("SELECT COUNT(*) FROM guestbook " );
if (!$zapros8) {echo mysql_error();}
else {$smarty->assign('messages', mysql_fetch_array($zapros8));
}

$zapros8 = mysql_query("SELECT COUNT(*) FROM muzx_songs WHERE hidden='0' " );
if (!$zapros8) {echo mysql_error();}
else {$smarty->assign('tunes', mysql_fetch_array($zapros8));
}


$zapros8 = mysql_query("SELECT nickname, id FROM muzx_authors WHERE years_to>'2008' ORDER BY nickname" );
if (!$zapros8) {echo mysql_error();}
else {$n=0;
while ($g = mysql_fetch_array($zapros8)) {
if ($n) {$act.=", ";}
$act.="<a href='author.php?id=".$g['id']."'>".$g['nickname']."</a>"; $n++;
}
}
$smarty->assign('act', $act);


$zapros8 = mysql_query("SELECT * FROM muzx_authors" );
if (!$zapros8) {echo mysql_error();}
else {$k_auth = mysql_num_rows($zapros8);
while ($gr = mysql_fetch_array($zapros8)) {

$yf=$gr['years_from'];
$yk=($gr['years_to']-$gr['years_from'])+1;
if ($yf) {for ($i=0; $i<$yk; $i++) {$yg[$yf+$i-1984]++;};}
}
}


$zapros18 = mysql_query("SELECT year FROM muzx_songs WHERE hidden='0' AND year!='0' " );
if (!$zapros18) {echo mysql_error();}
else {
while ($ys = mysql_fetch_array($zapros18)) { $songy["y".$ys['year']]++;}
}

for ($i=0; $i<25; $i++) {$gr.= "&yg".$i."=".$yg[$i];}
for ($i=1984; $i<2011; $i++) {$gr.= "&ys".$i."=".$songy["y".$i];}




$nm="images/grafik.png";
//if (file_exists($nm)) {$tm=ceil(filectime($nm)/43200);
//if ($tm!=ceil(time()/43200)) {unlink($nm); $img=require("http://zxtunes.com/grafik2.php?i=0&$gr");}
//}
//else {$img=require("http://zxtunes.com/grafik2.php?i=0&$gr");}
//$img=require("http://zxtunes.com/grafik2.php?i=0&$gr");


include "right_strip.php";  



$smarty->display('stats.tpl');

?>

