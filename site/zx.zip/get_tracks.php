<?php
require 'online.inc';

$id = $_REQUEST['id'];
if ($id) {$smarty->assign('id', $id);}


echo "<option value=0>трек</option>";

$z = mysql_query("SELECT * FROM  muzx_songs_authors,  muzx_songs WHERE author_id=$id AND id=song_id ORDER BY year" );
$n = 0;
while ($t = mysql_fetch_array($z)) {

	echo "<option value='".$t['id']."'>".$t['id']. " - ".$t['filename']." - ".$t['name']."</option>";

}

?>