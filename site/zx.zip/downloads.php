<?php
require 'ini.php';

$id = intval($_GET['id']);
$md = $_GET['md'];

$conn = mysql_connect (DB_HOST, DB_USER, DB_PASS);
@mysql_select_db (DB_NAME, $conn);

if ($md=="author") {

    $mysql_tmp= mysql_query ("SELECT nickname FROM muzx_authors WHERE id ='$id'" , $conn);
	if (mysql_num_rows ($mysql_tmp) >= 1)
	{$row = mysql_result ($mysql_tmp, 0);}
	
	mysql_query("UPDATE muzx_authors SET downloads=downloads+1 WHERE id='$id' LIMIT 1");
	$filepath = sprintf('tunes_zip/%08X', $id);

	if (file_exists ($filepath))
	{
		$songSize = filesize ($filepath);
		ob_clean();
	
		header('Content-type: application/octet-stream');
		header('Content-Disposition: attachment; filename='.$row.".zip");
		header("Content-Length: ".$songSize);
	
		readfile($filepath);
	}
	else {header("HTTP/1.0 404 Not Found");}
}

elseif ($md=="software") {

	mysql_query("UPDATE software_file SET downloads=downloads+1 WHERE id_file='$id' LIMIT 1");
    $mysql_tmp= mysql_query ("SELECT id_software, feature FROM software_file WHERE id_file ='$id'" , $conn);
	if (mysql_num_rows ($mysql_tmp) >= 1) {$row1 = mysql_fetch_array($mysql_tmp);}
	
	$ids=$row1['id_software'];
	$mysql_tmp= mysql_query ("SELECT * FROM software WHERE id ='$ids'" , $conn);
	if (!$mysql_tmp) {echo mysql_error();}
    else {$row = mysql_fetch_array($mysql_tmp);}
	

	$filepath = "software/files/".$id;
    
	if (file_exists ($filepath))
	{
		$songSize = filesize ($filepath);
		ob_clean();
	    $file_name=$row['title']."_".$row['version'];
		if ($row1['feature']) {$file_name.=" ".$row1['feature'];}
		$file_name.=".zip";
		$file_name=str_replace(" ", "_",$file_name);
		header('Content-type: application/octet-stream');
		header('Content-Disposition: attachment; filename='.$file_name);
		header("Content-Length: ".$songSize);
	
		readfile($filepath);
	}
	else {header("HTTP/1.0 404 Not Found");}
}

elseif ($md=="remix_mp3") {

  $mysql_tmp= mysql_query ("SELECT file_name,year FROM remix_mp3 WHERE id ='$id'" , $conn);
  if (!$mysql_tmp) {echo mysql_error();}
  else {$row = mysql_fetch_array($mysql_tmp);
  
  mysql_query("UPDATE remix_mp3 SET downloads=downloads+1 WHERE id='$id' LIMIT 1 ");
  
  if ($row['year']) {$year=$row['year']."/";}
    
  header("Location: http://zxtunes.com/remix_mp3/".$year.$row['file_name']);
  }
  exit;	

}

elseif ($md=="podcast") {

  $mysql_tmp= mysql_query ("SELECT file_name FROM podcast WHERE id ='$id'" , $conn);
  
  if (!$mysql_tmp) {
  
		echo mysql_error();
		
  }
  else {
  
	$row = mysql_fetch_array($mysql_tmp);
  
	mysql_query("UPDATE podcast SET downloads=downloads+1 WHERE id='$id' LIMIT 1 ");

	header("Location: http://zxtunes.com/podcast/".$row['file_name']);
  }
  exit;	

}

else {

	$mysql_tmp= mysql_query ("SELECT filename FROM muzx_songs WHERE id ='".$id."'" , $conn);
	if (mysql_num_rows ($mysql_tmp) >= 1)
	{$row = mysql_result ($mysql_tmp, 0);}
	
	$filepath = sprintf('tunes/%08X', $id);

	mysql_query("UPDATE muzx_songs SET downloads=downloads+1 WHERE id='$id' LIMIT 1 ");

	if (file_exists ($filepath))
	{
		$songSize = filesize ($filepath);
		ob_clean();
	
		header('Content-type: application/octet-stream');
		header('Content-Disposition: attachment; filename='.$row);
		header("Content-Length: ".$songSize);
	
		readfile($filepath);
	}
	else {header("HTTP/1.0 404 Not Found");}
}
	
?>