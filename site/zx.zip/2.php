<?php

require 'ini.php';

$z = mysql_query("SELECT * FROM muzx_authors");
while ($t = mysql_fetch_array($z)) { 
	
	if ($t['also']) {
	
		$also = $t['also'];
		$id = $t['id'];
		
		if ($t['also2']) { $also .= ", ".$t['also2'];}
		if ($t['also3']) { $also .= ", ".$t['also3'];}
		if ($t['also4']) { $also .= ", ".$t['also4'];}
		if ($t['also5']) { $also .= ", ".$t['also5'];}
		
		mysql_query("UPDATE muzx_authors SET also='$also' WHERE id='$id' LIMIT 1 ");
		
		echo $also ."<br>";
		
	}
	
}


?>