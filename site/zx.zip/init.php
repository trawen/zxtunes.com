<?php 

define('nm_post_in_page', 7);
define('nm_news_in_page', 8);
define('nm_pages_list', 15);

$link_1_name = 'board';
$link_1_id = 'id';
$link_2_name = 'read';
$link_2_id = 'id';




define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'HNkDA1TQ');
define('DB_NAME', 'zxtunes');


function initDB()
{
	mysql_connect(DB_HOST, DB_USER, DB_PASS)
		or die(mysql_error());
	mysql_select_db(DB_NAME)
		or die(mysql_error());
	mysql_query("SET NAMES 'cp1251'");

}

initDB();


$dir = "/var/www/newart/data/www/zxtunes.com/";
define('SMARTY_DIR', $dir.'smarty/libs/');
require_once(SMARTY_DIR . 'Smarty.class.php');
$smarty = new Smarty;

$smarty->template_dir = $dir.'smarty/zxtunes/templates/';
$smarty->compile_dir = $dir.'smarty/zxtunes/templates_c/';
$smarty->config_dir = $dir.'smarty/zxtunes/configs/';
$smarty->cache_dir = $dir.'smarty/zxtunes/cache/';

$smarty->assign('rnd_image', rand(1,5));

$smarty->assign('link_1_id', $link_1_id);
$smarty->assign('link_1_name', $link_1_name);
$smarty->assign('link_2_id', $link_2_id);
$smarty->assign('link_2_name', $link_2_name);

?>