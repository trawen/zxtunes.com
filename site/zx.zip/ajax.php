<?php
include 'common.inc.php';
initDB();
  
$zapros = mysql_query("SELECT * FROM muzx_songs" );

while ($t = mysql_fetch_array($zapros)) { 

	$id = $t['id'];

	mysql_query("UPDATE muzx_songs SET comments=0 WHERE id='$id AND comments <> 1'");	
	
}

?>