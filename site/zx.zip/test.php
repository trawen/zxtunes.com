<?php
// outputs the username that owns the running php/httpd process
// (on a system with the "whoami" executable in the path)
echo system('/zx/zxtune123 --clockrate 1773400 --convert mode=fym,filename=test.fym Dominion_14.pt3');
?>