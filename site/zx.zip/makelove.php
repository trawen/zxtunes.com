<?php
require 'ini.php';






//error_reporting(E_ALL | E_STRICT);

$smarty->assign('goto', $_REQUEST['goto']);

function geturl($i){}


$z = mysql_query("SELECT id,nickname,city FROM muzx_authors ORDER BY nickname" );
while ($t = mysql_fetch_array($z)) {
  
	$m[] = $t;
		
}
$smarty->assign('musicians', $m);

include "right_strip.php";  	
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	

// ВЫХОД
if ($_REQUEST['goto'] == 'hell') {

	unset($_SESSION['password']);
	unset($_SESSION['login']); 
	unset($_SESSION['auto']);
	unset($_SESSION['id']);

}// АКТИВАЦИЯ ЛОГИНА
elseif ($_REQUEST['goto'] == 'start') {

	//mysql_query ("DELETE FROM users WHERE activation='0' AND UNIX_TIMESTAMP() - UNIX_TIMESTAMP(date) > 3600");


	$code  = htmlspecialchars($_GET['code']);
	$login = htmlspecialchars($_GET['login']);


	$result = mysql_query("SELECT id FROM users WHERE login='$login' AND activation='0'");
	$myrow = mysql_fetch_array($result); 

	$activation = md5($myrow['id']).md5($login);

	if ($activation == $code) {
		
		mysql_query("UPDATE users SET activation='1' WHERE login='$login'");
		
		$_SESSION['error'] = 163;
		header("Location: http://zxtunes.com/makelove.php");
		exit;
		
	}
	else {
	
		$_SESSION['error'] = 122;
		header("Location: http://zxtunes.com/makelove.php");
		exit;
			
	}

	
}// СОЗДАНИЕ НОВОГО ПАРОЛЯ
elseif ($_REQUEST['goto'] == 'totalrecall' and $_REQUEST['submit'] == "Отправить") {


	$smarty->assign('login', $_POST['login']);
	$smarty->assign('email', $_POST['email']);

	$login = htmlspecialchars(trim($_POST['login']));
	$email = htmlspecialchars(trim($_POST['email']));
	
	
	$result = mysql_query("SELECT id FROM users WHERE login='$login' AND email='$email' AND activation='1'");
	$myrow = mysql_fetch_array($result);
	
	if (empty($myrow['id']) or $myrow['id']=='') {
		
		$_SESSION['error'] = 1;
			
		echo "fuck";	
			
		//header("Location: http://zxtunes.com/makelove.php?goto=totalrecall");
		exit;
	
	}
	
	require 'email.inc';
	
	$datenow = date('YmdHis');
	$new_password = md5($datenow);
	$new_password = substr($new_password, 2, 6);	
	
	$new_password_sh = strrev(md5($new_password))."b3p6f";
	mysql_query("UPDATE users SET password='$new_password_sh' WHERE login='$login'");
		
	$message = "Здравствуйте, ".$login."! \n\nМы сгененриоровали для Вас новый пароль. \nПосле входа желательно его сменить. \n\nПароль: ".$new_password."\n\nАдминистрация www.zxtunes.com";;
		
	send_email($_POST['email'], $_POST['login'], "Восстановление пароля", $message);
				
	$_SESSION['error'] = 124;
			
	header("Location: http://zxtunes.com/makelove.php");
	exit;
	
}// СМЕНА ПАРОЛЯ И АВАТАРА
elseif ($_REQUEST['goto'] == 'alterego' and ($_REQUEST['new_password'] or $_FILES['avatar_upload']['name'])) {

	require 'avatar.inc';
	
	$avatar = avatar($_SESSION['id']);

	$password = md5($_REQUEST['new_password']);
	$password = strrev($password);
	$password = $password."b3p6f";
	
	if ($_REQUEST['new_password'] and $avatar) {
			
		mysql_query("UPDATE users SET password='$password', avatar='$avatar' WHERE login='".$_SESSION['login']."' AND password='".$_SESSION['password']."' AND id='".$_SESSION['id']."'");
		
		$_SESSION['password'] = $password; 
	
	}
	elseif ($_REQUEST['new_password']) {
	
		mysql_query("UPDATE users SET password='$password' WHERE login='".$_SESSION['login']."' AND password='".$_SESSION['password']."' AND id='".$_SESSION['id']."'");
		
		$_SESSION['password'] = $password; 
	
	}
	elseif ($avatar) {
	
		mysql_query("UPDATE users SET avatar='$avatar' WHERE login='".$_SESSION['login']."' AND password='".$_SESSION['password']."' AND id='".$_SESSION['id']."'");
	
	}
	
	header("Location: http://zxtunes.com/makelove.php?goto=alterego");
	exit;

}
elseif ($_REQUEST['goto'] == 'push' and $_REQUEST['submit'] == "Войти") {


	$login = htmlspecialchars(trim($_POST['login']));
	$password = htmlspecialchars(trim($_POST['password']));
	
	$password = md5($password);
	$password = strrev($password);
	$password = $password."b3p6f";
		

	$result = mysql_query("SELECT * FROM users WHERE login='$login' AND password='$password' AND activation='1'"); 
	$myrow = mysql_fetch_array($result);
	
	
		
		if (empty($myrow['id'])) {

	
			$ip=getenv("HTTP_X_FORWARDED_FOR");
			if (empty($ip) || $ip=='unknown') { $ip=getenv("REMOTE_ADDR"); }

			mysql_query ("DELETE FROM oshibka WHERE UNIX_TIMESTAMP() - UNIX_TIMESTAMP(date) > 300");//удаляем ip-адреса ошибавшихся при входе пользователей через 15 минут.

			$result = mysql_query("SELECT * FROM oshibka WHERE ip='$ip'");// извлекаем из базы колличество неудачных попыток входа за последние 15 минут у пользователя с данным ip
			$myrow = mysql_fetch_array($result);
	
			if ($myrow['col'] >= 5) {
			
				$_SESSION['error'] = 5;
				header("Location: http://zxtunes.com/makelove.php");
				exit;
			
			}
	
		
			$select = mysql_query ("SELECT ip FROM oshibka WHERE ip='$ip'");
			$tmp = mysql_fetch_row ($select);

			if ($ip == $tmp[0]) {

				//проверяем, есть ли пользователь в таблице "oshibka"
				$result52 = mysql_query("SELECT col FROM oshibka WHERE ip='$ip'");
				$myrow52 = mysql_fetch_array($result52);

				mysql_query ("UPDATE oshibka SET col=col+1,date=NOW() WHERE ip='$ip'");
			}

			else {

			//если за последние 15 минут ошибок не было, то вставляем новую запись в таблицу "oshibka"
			mysql_query ("INSERT INTO oshibka (ip,date,col) VALUES ('$ip',NOW(),'1')");

			}
			
			$_SESSION['error'] = 3;


		}
		else {
    
			//если пароли совпадают, то запускаем пользователю сессию! Можете его поздравить, он вошел!
			$_SESSION['password'] = $myrow['password']; 
			$_SESSION['login'] = $myrow['login']; 
			$_SESSION['id'] = $myrow['id'];
				
	
	
			setcookie("user_login", $myrow['login'], time()+9999999);
			setcookie("user_password", $myrow['password'], time()+9999999);
			setcookie("user_id", $myrow['id'], time()+9999999);
	
	
			exit;
			
			
			if ($_SESSION['redirect']) {
			
				header("Location: ".$_SESSION['redirect']);
				exit;
			
			}
			
			
		}	
	

}// РЕГИСТРАЦИЯ
elseif ($_REQUEST['goto'] == 'stargate' and $_REQUEST['submit'] == "Зарегистрироваться") {
	
	$author_id = intval($_POST['author_id']);
	$email = htmlspecialchars(trim($_POST['email']));
	$login = mysql_real_escape_string(htmlspecialchars(trim($_POST['login'])));
	$password = htmlspecialchars(trim($_POST['password']));

	//require 'captcha.inc';


	//if (!chec_code($_POST['code'])) {

	//	$_SESSION['error'] = 9;

	//}
	//else
	if (strlen($login) < 3 or strlen($login) > 15 or strlen($password) < 3 or strlen($password) > 15 or !preg_match("/[0-9a-z_]+@[0-9a-z_^\.]+\.[a-z]{2,3}/i", $email)) {

		$_SESSION['error'] = 4;

	}
	else {

		$password = md5($password);
		$password = strrev($password);
		$password = $password."b3p6f";


		// проверка на существование пользователя с таким же логином
		$result = mysql_query("SELECT id FROM users WHERE login='$login'");// OR email='$email'");
		$myrow = mysql_fetch_array($result);
	
		if (!empty($myrow['id'])) {

			$_SESSION['error'] = 6;

		}
		else {

			$tm = time();
			// если такого нет, то сохраняем данные
			$result2 = mysql_query ("INSERT INTO users (login,password,avatar,email,date,author_id) VALUES('$login','$password','$avatar','$email','$tm','$author_id')");

			// Проверяем, есть ли ошибки
			if ($result2=='TRUE') {

				$result3 = mysql_query ("SELECT id FROM users WHERE login='$login'");
				$myrow3 = mysql_fetch_array($result3);
				$activation = md5($myrow3['id']).md5($login);

				
				
				$subj = "Подтверждение регистрации";
				$message = "Здравствуйте, $login!\n\nБлагодарим за регистрацию на www.zxtunes.com\n\nЧтобы  активировать ваш аккаунт, перейдите по ссылке:\n\nhttp://zxtunes.com/makelove.php?goto=start&login=".rawurlencode($login)."&code=".$activation."\n\nАдминистрация www.zxtunes.com";

				require 'email.inc';
			
				if (!send_email($email, $login, $subj, $message)) {
			
					$_SESSION['error'] = 100;
					header("Location: http://zxtunes.com/makelove.php?goto=stargate");
					exit;
				
				}
				else {
			
					$_SESSION['error'] = 10;
	
				}

			}
			else {

				$_SESSION['error'] = 7;

			}	
		}
	}
}





// NO LOGIN, FUCKYOU!
if ($_REQUEST['goto'] == 'alterego' and !login()) {

	header("Location: http://zxtunes.com/makelove.php");
	exit;

}











if (!empty($_SESSION['login']) and !empty($_SESSION['password'])) {

	$login = $_SESSION['login'];
	$password = $_SESSION['password'];

	$result = mysql_query("SELECT * FROM users WHERE login='$login' AND password='$password' AND activation='1' LIMIT 1"); 
	$myrow = mysql_fetch_array($result);

}



if (isset($myrow['id']) and $myrow['id']) {

	$smarty->assign('user', $myrow);
	
}


$smarty->assign('error', $_SESSION['error']);
unset($_SESSION['error']);

$smarty->display('login.tpl');
?>