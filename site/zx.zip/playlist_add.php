<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '18gWNUai');
define('DB_NAME', 'zxtunes');

$conn = mysql_connect (DB_HOST, DB_USER, DB_PASS);
@mysql_select_db (DB_NAME, $conn);



$user_id = intval($_REQUEST['user_id']);
$song_id = intval($_REQUEST['song_id']);

$tm = time();
$true = strpos($_SERVER['HTTP_REFERER'], "zxtunes.com");



if ($user_id and $song_id and $true) {

	$z = mysql_query("SELECT id FROM playlists WHERE user_id='$user_id' AND type='1' LIMIT 1");
	$t = mysql_fetch_array($z); 
	$playlist_id = $t[0];
	
	
	$z = mysql_query("SELECT id FROM playlists_songs WHERE playlist_id='$playlist_id' AND song_id='$song_id' LIMIT 1");$ts = mysql_fetch_array($z); 
		
	if (!$ts and $playlist_id) {
	
		mysql_query("INSERT INTO `playlists_songs` (`song_id`,`playlist_id`) VALUES ('$song_id', '$playlist_id')");
		mysql_query("UPDATE playlists SET numbers=numbers+1 WHERE id='$playlist_id' LIMIT 1");
	
	}
		
}

?>