<?php
require 'online.inc';

if ($_REQUEST['delete_id']) {

	$id = intval($_REQUEST['delete_id']);
	mysql_query("DELETE FROM wait_fym WHERE wf_id='$id' LIMIT 1 "); echo mysql_error();

	echo "ok";
	exit;

}



//$z = mysql_query("SELECT * FROM wait_fym, muzx_songs WHERE muzx_songs.id=wf_id_song" ); echo mysql_error();
$z = mysql_query("SELECT id,type FROM muzx_songs" ); echo mysql_error();



$n=0;
while ($t = mysql_fetch_array($z)) { 
	
	//$e = $e . $t['wf_id'].",".$t['wf_id_song'].",".$t['wf_id_author'].",".$t['type']."/";
	$e = $e . $t['id'].",".$t['type']."/";
					
}

header('Content-type: application/octet-stream');
header('Content-Disposition: attachment; filename=fuck');
header("Content-Length: ".strlen($e));

echo $e;

?>