<?php
require 'online.inc';
if (!$_SESSION['return_url']) {$_SESSION['return_url']=$_SERVER['HTTP_REFERER']; }


$username = $_POST['username'];
$password = $_POST['password'];
$login = $_REQUEST['login'];
$md = $_REQUEST['md'];
$email=$_REQUEST['email'];
$autologin=$_REQUEST['autologin'];








if ($login=="Log in") {

	$zapros = mysql_query("SELECT * FROM users WHERE username='$username' and password='$password' ");

	if (!$zapros) {echo mysql_error();}
	else {$user = mysql_fetch_array($zapros);
	if ($user['id']) {
		$_SESSION['user_id']=$user['id'];
		$_SESSION['username']=$user['username'];
		$_SESSION['status']=$user['status'];
		//echo "#".$_SESSION['user_id']."#".$_SESSION['username']."#".$_SESSION['status'];
		if ($autologin) {//$r_mes.="COOKYE!!";
	    $tm = mktime(0,0,0,1,1,2009);
        setcookie('login_id', $user['id'], $tm);
		setcookie('login_username', $user['username'], $tm);
		setcookie('login_password', $user['password'], $tm);
		}
	}
	}
	if (!$_SESSION['user_id']) {$r_mes.="<br>You have specified an incorrect or inactive username, or an invalid password.";}
	else {
	  if ($r_mes) {$_SESSION['r_mes']=$r_mes."<br>";}
	  $u=$_SESSION['return_url'];
	  $_SESSION['return_url']=0;
      header("Location: ".$u);
      exit;	
         }
}
	
	
	
	
elseif ($login=="Send") {

	$zapros = mysql_query("SELECT * FROM users WHERE email='$email' LIMIT 1");

	if (!$zapros) {echo mysql_error();}
	else {$test = mysql_fetch_array($zapros);}
	
	if (!$test['id']) {$r_mes.="<br>You have specified an incorrect E-Mail adress.";}
	else {
	
		require("mailer/class.phpmailer.php");

		$mail = new PHPMailer();


		$mail->From = "naawaj@gmail.com";
		$mail->FromName = "zxtunes";
		$mail->AddAddress($email);
		$mail->AddReplyTo("info@example.com", "Information");
		$mail->WordWrap = 50;                                 
		$mail->IsHTML(true);                                  
		$mail->Subject = "Your password for 'www.zxtunes.com'.";
		$mail->Body    = "password: ".$test['password']."<br><br><a href='http://zxtunes.com/login.php'>Log in...<a>";
		$mail->AltBody = "password: ".$test['password'];
	
		if(!$mail->Send()) {$r_mes.="<br>Password could not be sent.<br>Mailer Error: ".$mail->ErrorInfo;}
		else {$r_mes.="<br>The password has been sent to you E-Mail."; $md="";}
    }
}


elseif ($login=="Submit") {
	$username = $_REQUEST['username'];
	$email = $_REQUEST['email'];
	$password = $_REQUEST['password'];
	$password_confirm = $_REQUEST['password_confirm'];
	$confirm_id = $_REQUEST['confirm_id'];
	$confirm_code = strtoupper($_REQUEST['confirm_code']);
	$icq = $_REQUEST['icq'];
	$email_pub = $_REQUEST['email_pub'];
	$url = $_REQUEST['url'];
	$first_name = $_REQUEST['first_name'];
	$last_name = $_REQUEST['last_name'];
	$city = $_REQUEST['city'];
	$country = $_REQUEST['country'];
	$ip=$_SERVER["REMOTE_ADDR"];
	$auid = $_REQUEST['author'];
	
	$a=1;
	for ($i=1; $i<9; $i++) {$cc2.=substr($confirm_id, $a, 1); $a=$a+2;}


	$err=0;
	$error[1]="The passwords you entered did not match.";
	$error[2]="You must fill in the required fields.";
	$error[4]="The confirmation code you entered was incorrect.";
	$error[8]="Password too short.";
	$error[16]="Sorry, but this username has already been taken.";
	$error[32]="MySQL error 2.";

	
	if ($password != $password_confirm) {$err=$err | 1;} 
	if (!$username or !$email or !$password or !$password_confirm) {$err=$err | 2;}
	if ($cc2 != $confirm_code or strlen($cc2)!=8) {$err=$err | 4;}
	if (strlen($password)<8) {$err=$err | 8;} 
	
	$zapros = mysql_query("SELECT * FROM users WHERE username='$username'");
	$us = mysql_fetch_array($zapros);
	if ($us['username']==$username and $username) {$err=$err | 16;}
	
	if ($err==0) {
	$ins=mysql_query("INSERT INTO users (`id`, `id_authors`, `username`, `password`, `first_name`, `last_name`, `city`, `country`, `icq`, `email`, `email_pub`, `url`, `status`, `ip`) VALUES (NULL, '$auid', '$username', '$password', '$first_name', '$last_name', '$city', '$country', '$icq', '$email', '$email_pub', '$url', '0', '$ip') ");
	
	if (!$ins) {$err=$err | 32;}
	}
	
	
	if ($err>0) {$a=1; for ($i=1; $i<7; $i++) { if ($err & $a) {$r_mes.="<br>".$error[$err & $a];} $a=$a * 2;};}
	else {$r_mes.="<br>Registration OK!";
	  if ($r_mes) {$_SESSION['r_mes']=$r_mes."<br>";}
      header("Location: http://zxtunes.com/login.php");
      exit;
	}
}	
		 





	
	
require 'menu_top.php';


if ($_SESSION['r_mes']) {echo "<b><div align='center' class='tx12'>".$_SESSION['r_mes']."</div></b>"; $_SESSION['r_mes']="";}
if ($r_mes) {echo "<b><div align='center' class='tx12'>".$r_mes."</div></b>";}
if ($md=="send_password") {require 'send_password.inc';}
elseif ($md=="registration") {require 'registration.inc';}
else {require 'login.inc';}





?>