<?php
require 'ini.php';

function geturl($i){
  $a="/search.php?";
  return $a;
}

$ip=$_SERVER["REMOTE_ADDR"];
$client = " ".$_SERVER[HTTP_USER_AGENT]; 
if(strstr($client,"Yandex") or strstr($client,"Googlebot")) {$bot=1;} else {$bot=0;}

if ($bot) {header("Location: ".$_SESSION['last_url']); exit;}

function getext ($i) {
$n=strlen($i)-1;
while (substr($i, $n, 1)!=".") {$res.=substr($i, $n, 1); $n--; if (!$n) {break;};}
$res=strtolower(strrev($res));
return $res;
}


function microtime_float()
{
    list($usec, $sec) = explode(" ", microtime());
    return ((float)$usec + (float)$sec);
}


$author_id=$_REQUEST['id'];
$message=$_REQUEST['message'];
$user_name=$_REQUEST['user_name'];
$user_email=$_REQUEST['user_email'];
$user_site=$_REQUEST['user_site'];
$user_from=$_REQUEST['user_from'];
$submit=$_REQUEST['submit'];
$code=$_REQUEST['code'];
$confirm_code = $_REQUEST['confirm_code'];
$mode = $_REQUEST['mode'];
$c=explode("+", $code);
$c=trim($c[0])+trim($c[1]);


//$smarty->debugging = true;
$smarty->compile_check = true;

$tm=time(); 
$ip=$_SERVER["REMOTE_ADDR"];



$smarty->assign('search', $sr);


if ($submit=="submit" or $submit=="OK") {


$smarty->assign('srtext', $_REQUEST['srtext']);
$srtext=mb_strtolower($_REQUEST['srtext'], "UTF-8");

$srtype=$_REQUEST['srtype'];
if (strlen($srtext)>=2 and strlen($srtext)<32) {


if ($srtype=="authors") {
$v = mysql_query("SELECT * FROM muzx_authors WHERE nickname LIKE '%$srtext%' OR also LIKE '%$srtext%' OR first_name LIKE '%$srtext%' OR last_name LIKE '%$srtext%'  OR group_name LIKE '%$srtext%'" );
	 
if (!$v) {echo mysql_error();}
else { $n=0;
while ($src = mysql_fetch_array($v)) {

$src['nickname']=" ".$src['nickname'];
$p=strpos ( strtolower($src['nickname']) , $srtext);
 if ($p) {$src['nickname']=substr($src['nickname'],1,$p-1)."<b style='COLOR: #e08200'>".substr($src['nickname'],$p,strlen($srtext))."</b>".substr($src['nickname'],$p+strlen($srtext));}
 $src['nickname']=trim($src['nickname']);
 

$src['group_name']=" ".$src['group_name'];
$p=strpos ( strtolower($src['group_name']) , $srtext);
 if ($p) {$src['group_name']=substr($src['group_name'],1,$p-1)."<b style='COLOR: #e08200'>".substr($src['group_name'],$p,strlen($srtext))."</b>".substr($src['group_name'],$p+strlen($srtext));}
 $src['group_name']=trim($src['group_name']); 


if ($_SESSION['language']=="rus") {
$src['first_name']=" ".$src['first_name'];
$p=mb_strpos ( mb_strtolower($src['first_name'], "UTF-8") , $srtext, "UTF-8");
 if ($p) {$src['first_name']=mb_substr($src['first_name'],1,$p-1)."<b style='COLOR: #e08200'>".mb_substr($src['first_name'],$p,strlen($srtext))."</b>".mb_substr($src['first_name'],$p+mb_strlen($srtext));}
 
$src['last_name']=" ".$src['last_name'];
$p=mb_strpos (mb_strtolower($src['last_name']) , $srtext);
 if ($p) {$src['last_name']=mb_substr($src['last_name'],1,$p-1)."<b style='COLOR: #e08200'>".mb_substr($src['last_name'],$p,mb_strlen($srtext))."</b>".mb_substr($src['last_name'],$p+mb_strlen($srtext));}
$src['first_name']=trim($src['first_name']);
$src['last_name']=trim($src['last_name']);
}

else {
$src['first_name_en']=" ".$src['first_name_en'];
$p=strpos ( strtolower($src['first_name_en']) , $srtext);
 if ($p) {$src['first_name_en']=substr($src['first_name_en'],1,$p-1)."<b style='COLOR: #e08200'>".substr($src['first_name_en'],$p,strlen($srtext))."</b>".substr($src['first_name_en'],$p+strlen($srtext));}
 
$src['last_name_en']=" ".$src['last_name_en'];
$p=strpos ( strtolower($src['last_name_en']) , $srtext);
 if ($p) {$src['last_name_en']=substr($src['last_name_en'],1,$p-1)."<b style='COLOR: #e08200'>".substr($src['last_name_en'],$p,strlen($srtext))."</b>".substr($src['last_name_en'],$p+strlen($srtext));}
$src['first_name_en']=trim($src['first_name_en']);
$src['last_name_en']=trim($src['last_name_en']);
}

 
if ($src['also1']) {
$src['also1']=" ".$src['also1'];
$p=strpos ( strtolower($src['also1']) , $srtext);
if ($p) {$src['also1']=substr($src['also1'],1,$p-1)."<b style='COLOR: #e08200'>".substr($src['also1'],$p,strlen($srtext))."</b>".substr($src['also1'],$p+strlen($srtext));}
$src['also1']=trim($src['also1']);
}


if ($src['also2']) {
$src['also2']=" ".$src['also2'];
$p=strpos ( strtolower($src['also2']) , $srtext);
if ($p) {$src['also2']=substr($src['also2'],1,$p-1)."<b style='COLOR: #e08200'>".substr($src['also2'],$p,strlen($srtext))."</b>".substr($src['also2'],$p+strlen($srtext));}
$src['also2']=trim($src['also2']);
}

if ($src['also3']) {
$src['also3']=" ".$src['also3'];
$p=strpos ( strtolower($src['also3']) , $srtext);
if ($p) {$src['also3']=substr($src['also3'],1,$p-1)."<b style='COLOR: #e08200'>".substr($src['also3'],$p,strlen($srtext))."</b>".substr($src['also3'],$p+strlen($srtext));}
$src['also3']=trim($src['also3']);
}

if ($src['also4']) {
$src['also4']=" ".$src['also4'];
$p=strpos ( strtolower($src['also4']) , $srtext);
if ($p) {$src['also4']=substr($src['also4'],1,$p-1)."<b style='COLOR: #e08200'>".substr($src['also4'],$p,strlen($srtext))."</b>".substr($src['also4'],$p+strlen($srtext));}
$src['also4']=trim($src['also4']);
}


if ($src['also5']) {
$src['also5']=" ".$src['also5'];
$p=strpos ( strtolower($src['also5']) , $srtext);
if ($p) {$src['also5']=substr($src['also5'],1,$p-1)."<b style='COLOR: #e08200'>".substr($src['also5'],$p,strlen($srtext))."</b>".substr($src['also5'],$p+strlen($srtext));}
$src['also5']=trim($src['also5']);
}

$src['nm']=$n+1;
$id=$src['id'];

$sr[$n]=$src;
$n++;
}
}
if ($n==1) {header("Location: http://zxtunes.com/author.php?id=".$id); exit;}
else {

$smarty->assign('klsr', $n);
$smarty->assign('search', $sr);

}

}



elseif ($srtype=="software") {
$v = mysql_query("SELECT title, author, id, version FROM software WHERE title LIKE '%$srtext%' OR author LIKE '%$srtext%'" );
echo mysql_error();

if (!$v) {echo mysql_error();}
else { $n=0;
while ($src = mysql_fetch_array($v)) {
$src['title']=" ".$src['title'];
$p=strpos ( strtolower($src['title']) , $srtext);
 if ($p) {$src['title']=substr($src['title'],1,$p-1)."<b style='COLOR: #e08200'>".substr($src['title'],$p,strlen($srtext))."</b>".substr($src['title'],$p+strlen($srtext));}
 $src['title']=trim($src['title']);
 
$src['author']=" ".$src['author'];
$p=strpos ( strtolower($src['author']) , $srtext);
 if ($p) {$src['author']=substr($src['author'],1,$p-1)."<b style='COLOR: #e08200'>".substr($src['author'],$p,strlen($srtext))."</b>".substr($src['author'],$p+strlen($srtext));}
 $src['author']=trim($src['author']);

$src['nm']=$n+1;
$id=$src['id'];

$sr[$n]=$src;
$n++;
}
}
if ($n==1) {header("Location: http://zxtunes.com/software.php?id=".$id); exit;}
else {

$smarty->assign('klsr', $n);
$smarty->assign('search', $sr);

}
}



elseif ($srtype=="tunes") {



$time_start = microtime_float();




$v = mysql_query("SELECT * FROM (SELECT * from muzx_songs WHERE muzx_songs.filename LIKE '%$srtext%' OR muzx_songs.name LIKE '%$srtext%') a JOIN muzx_songs_authors b ON (a.id = b.song_id) JOIN muzx_authors c ON (c.id = b.author_id) ORDER BY c.nickname LIMIT 350");
echo mysql_error();

unset($_SESSION['srid']);
unset($_SESSION['srnk']);


$n=0;
while ($src = mysql_fetch_array($v)) {


	if ($src['hidden']==0 and $src['denied']==0) {
	
	$src['filename']=" ".$src['filename'];
	$p=strpos ( strtolower($src['filename']) , $srtext);
	if ($p) {$src['filename']=htmlentities(substr($src['filename'],1,$p-1))."<b style='COLOR: #e08200'>".htmlentities(substr($src['filename'],$p,strlen($srtext)))."</b>".htmlentities(substr($src['filename'],$p+strlen($srtext)));}
	$src['filename']=trim($src['filename']);
 
	$src['name']=" ".$src['name'];
	$p=strpos ( strtolower($src['name']) , $srtext);
	if ($p) {$src['name']=htmlentities(substr($src['name'],1,$p-1))."<b style='COLOR: #e08200'>".htmlentities(substr($src['name'],$p,strlen($srtext)))."</b>".htmlentities(substr($src['name'],$p+strlen($srtext)));}
	$src['name']=trim($src['name']);

	$src['nm']=$n+1;
	$src['id'] = $src['song_id'];
		
	$srid[$n] = $src['song_id'];
	$srnk[$n] = $src['nickname'];
	
	$ri = $src['id'];
	if ($_REQUEST['rt'.$ri]) {$src['rt'] = "r_off";} else {$src['rt'] = "rating";}


	$sr[$n]=$src;
	$n++;
}
}


for($x=0; $x<$n; $x++) {

    $sr[$x]['next_id'] = $sr[$x+1]['id'];
	$sr[$x]['prev_id'] = $sr[$x-1]['id'];
	
}
$sr[0]['prev_id'] = $sr[$n-1]['id'];
$sr[$n-1]['next_id'] = $sr[0]['id'];








function clean_filename($filename) {
	$reserved = preg_quote('\/:*?"<>|', '/');
	return preg_replace("/([\\x00-\\x40\\x7f-\\xff{$reserved}])/e", "_", $filename);
}



$smarty->assign('klsr', $n);
$smarty->assign('search', $sr);
$_SESSION['srid']=$srid;
$_SESSION['srnk']=$srnk;
$_SESSION['srtx']=clean_filename($_REQUEST['srtext']);
$smarty->assign('srtx', $_SESSION['srtx']);
$smarty->assign('srsz',$n*1.2);
}

}

}

$smarty->assign('mdsr', $srtype);
if ($_SESSION['language']=="rus") {$smarty->assign('title', "Поиск - «".$_REQUEST['srtext']."»");}
else {$smarty->assign('title', "Search - «".$_REQUEST['srtext']."»");}










/// DOWNLOAD SEARCH FILES IN ZIP
if ($_REQUEST['download']) {

$srid=$_SESSION['srid'];
$smarty->assign('srid', $srid);
$srnk=$_SESSION['srnk'];
$smarty->assign('srnk', $srnk);


include_once('pclzip.lib.php');

function myPreAddCallBack($p_event, &$p_header)
{global $tname, $nik, $nm;
 $info = pathinfo($p_header['filename']);
if (!$info['extension']) {$p_header['stored_filename'] = $tname['t'.$p_header['stored_filename']][1]."_".$tname['t'.$p_header['stored_filename']][0];}
else {$p_header['stored_filename']=$info['basename'];}
return 1;
}

$nm=0;

while ($srid[$nm]) {

$id=$srid[$nm];


$zapros = mysql_query("SELECT filename FROM muzx_songs WHERE muzx_songs.id='$id' AND muzx_songs.hidden='0' AND muzx_songs.denied='0' " );
if (!$zapros) {echo mysql_error();}
else {$tunes = mysql_fetch_array($zapros); 

$hex=sprintf("%08X", $srid[$nm]);
$tlist.="tunes/".$hex.",";
$tname['t'.$hex][0]=$tunes['filename'];
$tname['t'.$hex][1]=$srnk[$nm];

}
$nm++;
}
$tlist=substr($tlist, 0, strlen($tlist)-1);



$sid=session_id();
mkdir("temp/".$sid, 0777);
$fn='temp/'.$sid.'/'.time();
$archive = new PclZip($fn);
$v_list = $archive->create($tlist, PCLZIP_CB_PRE_ADD, 'myPreAddCallBack', PCLZIP_OPT_REMOVE_PATH, 'tunes');
if ($v_list == 0) {echo "Error : ".$archive->errorInfo(true);}

$fs = filesize ($fn);
ob_clean();
	
header('Content-type: application/octet-stream');
header('Content-Disposition: attachment; filename=zxtunes_search_'.$_SESSION['srtx'].'.zip');
header("Content-Length: ".$fs);

readfile($fn);
unlink($fn);
rmdir("temp/".$sid);
unset($_SESSION['srid']);
unset($_SESSION['srnk']);
exit;
}

include "right_strip.php";  

$smarty->display('search.tpl');
?>

